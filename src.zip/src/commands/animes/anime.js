const Kitsu = require('kitsu.js'),
    kitsu = new Kitsu(),
    translate = require('@iamtraction/google-translate'),
    Error = require('../../../modules/functions/config/errors')

module.exports = {
    name: 'anime',
    aliases: ['searchanime', 'animes'],
    category: 'animes',
    ClientPermissions: ['EMBED_LINKS'],
    emoji: '🔍',
    usage: '<nome do anime>',
    description: 'Pesquisa de Animes',

    execute: async (client, message, args, prefix, MessageEmbed, Database) => {

        const e = Database.Emojis

        const EmbedApresetation = new MessageEmbed()
            .setColor('#246FE0')
            .setTitle('🔍 Pesquise Animes')
            .setDescription('Eu posso buscar informações sobre qualquer anime, quer tentar?')
            .addField('Comando', '`' + prefix + 'anime Nome Do Anime`')

        let search = args.join(" ")
        if (!search) { return message.reply({ embeds: [EmbedApresetation] }) }
        if (search.length > 100) return message.reply(`${e.Deny} | Por favor, tente algo com menos de **100 caracteres**, pelo bem do meu sistema ${e.Itachi}`)
        if (search.length < 4) return message.reply(`${e.Deny} | Por favor, tente algo com mais de **4 caracteres**, pelo bem do meu sistema ${e.SadPanda}`)

        kitsu.searchAnime(search).then(async result => {
            if (result.length === 0) return message.reply(`${e.Deny} | Nenhum resultado obtido para: **${search}**`).catch(() => { })

            let anime = result[0]

            let text = `${anime.synopsis.replace(/<[^>]*>/g, '').split('\n')[0]}`
            let pt = 'pt'
            translate(`${anime.synopsis.replace(/<[^>]*>/g, '').split('\n')[0]}`, { to: pt }).then(res => {

                let Nome = `${anime.titles.english ? anime.titles.english : search}`
                if (!Nome) Nome = 'Sem resposta'

                let Status = `${anime.showType}`
                if (Status === 'movie') Status = 'Filme'

                let Sinopse = `${res.text}`
                if (Sinopse.length > 1000) Sinopse = 'A sinopse ultrapassou o limite de **1000 caracteres**'
                if (Sinopse === 'null') Sinopse = 'Sem resposta'

                let NomeJapones = `${anime.titles.romaji}`
                if (NomeJapones === 'null') NomeJapones = 'Sem resposta'

                let IdadeRating = `${anime.ageRating}`
                if (IdadeRating === 'G') IdadeRating = 'Livre'
                if (IdadeRating === 'PG') IdadeRating = '+10'
                if (IdadeRating === 'PG-13') IdadeRating = '+15'
                if (IdadeRating === 'R') IdadeRating = '+18'
                if (IdadeRating === 'null') IdadeRating = 'Sem resposta'

                let NSFW = `${anime.nsfw ? 'Sim' : 'Não'}`
                if (NSFW === 'null') NSFW = 'Sem resposta'

                let Nota = `${anime.averageRating}`
                if (Nota === 'null') Nota = 'Sem resposta'

                let AnimeRanking = `${anime.ratingRank}`
                if (AnimeRanking === 'null') AnimeRanking = 'Sem resposta'

                let AnimePop = `${anime.popularityRank}`
                if (AnimePop === 'null') AnimePop = 'Sem resposta'

                let Epsodios = `${anime.episodeCount ? anime.episodeCount : 'N/A'}`
                if (Epsodios === 'null') Epsodios = 'Sem resposta'

                let Lancamento = `${anime.startDate}`
                if (Lancamento) Lancamento = `${new Date(Lancamento).toLocaleDateString("pt-br")}`

                let Termino = `${anime.endDate ? anime.endDate : "Ainda no ar"}`
                if (Termino === "Ainda no ar") {

                    const AnimeSearchEmbed = new MessageEmbed()
                        .setColor('GREEN')
                        .setTitle(`🔍 Pesquisa Requisitada: ${search}`)
                        .setDescription(`**📑 Sinopse**\n${Sinopse}`)
                        .addField('🗂️ Informações', `Nome Japonês: ${NomeJapones}\nFaixa Etária: ${IdadeRating}\nNSFW: ${NSFW}\NTipo: ${Status}`)
                        .addField('📊 Status', `Nota Média: ${Nota}\nRank: ${AnimeRanking}\nPopularidade: ${AnimePop}\nEpisódios: ${Epsodios}\nLancamento: ${Lancamento}\nTérmino: ${Termino}`)

                    anime.posterImage?.original ? AnimeSearchEmbed.setImage(anime.posterImage.original) : null

                    return message.reply({ embeds: [AnimeSearchEmbed] }).catch(err => {
                        Error(message, err)
                        return message.reply('Ocorreu um erro no comando "anime"\n`' + err + '`')
                    })

                } else {

                    const AnimeSearchEmbed = new MessageEmbed()
                        .setColor('GREEN')
                        .setTitle(`🔍 Pesquisa Requisitada: ${search}`)
                        .setDescription(`**📑 Sinopse**\n${Sinopse}`)
                        .addField('🗂️ Informações', `Nome Japonês: ${NomeJapones}\nFaixa Etária: ${IdadeRating}\nNSFW: ${NSFW}\nTipo: ${Status}`)
                        .addField('📊 Status', `Nota Média: ${Nota}\nRank: ${AnimeRanking}\nPopularidade: ${AnimePop}\nEpisódios: ${Epsodios}\nLancamento: ${Lancamento}\nTérmino: ${new Date(Termino).toLocaleDateString("pt-br")}`)

                    anime.posterImage?.original ? AnimeSearchEmbed.setImage(anime.posterImage.original) : null

                    return message.reply({ embeds: [AnimeSearchEmbed] }).catch(err => {
                        Error(message, err)
                        return message.reply('Ocorreu um erro no comando "anime"\n`' + err + '`')
                    })
                }
            }).catch(err => {
                Error(message, err)
                return message.reply(`${e.Warn} | Houve um erro ao executar este comando.\n\`${err}\``)
            })
        }).catch(err => {
            Error(message, err)
            return message.reply(`${e.Deny} | Nenhum resultado obtido para: **${search}**`).catch(err => {
                Error(message, err)
                return message.reply('Ocorreu um erro no comando "anime"\n`' + err + '`')
            })
        })
    }
}