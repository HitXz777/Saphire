module.exports = {
    name: 'invisivel',
    aliases: ['invisible'],
    usage: 'invisivel',
    
    
    emoji: '⠀',
    category: 'random',
    description: 'Caracteres invisíveis',

    run: async (client, message, args, prefix, MessageEmbed, Database) => { return message.reply('⠀⠀⠀⠀⠀⠀⠀⠀') }
}