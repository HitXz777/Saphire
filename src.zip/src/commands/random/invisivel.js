module.exports = {
    name: 'invisivel',
    aliases: ['invisible'],
    usage: 'invisivel',
    emoji: '⠀',
    category: 'random',
    description: 'Caracteres invisíveis',

    execute: async (client, message, args, prefix, MessageEmbed, Database) => message.reply('⠀⠀⠀⠀⠀⠀⠀⠀')
    }